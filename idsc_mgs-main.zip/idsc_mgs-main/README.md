# idsc_mgs
This website covers the material for Introduction to Applied Data Science.
